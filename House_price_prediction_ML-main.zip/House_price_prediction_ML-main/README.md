# House_price_prediction_ML

## MODEL

Run the ML model by running the jupyter notebook
> House_price_prediction.ipynb

The algorithm used here is the **Multiple Linear Regression**

## Visualization

The visualization of the model-trained 

<img width="353" alt="image" src="https://github.com/sam-1508/House_price_prediction_ML/assets/125907034/25507821-beb1-463d-add1-1aca649f96fc">
